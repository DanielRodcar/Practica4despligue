package es.studium.Libros;

public class LibroListado implements Cloneable {
  private int id;
  private String titulo;
  private String autor;
  private double precio;
  
  public LibroListado() {
    setId(0);
    titulo = "";
    autor = "";
    precio = 0.0;
  }
  public LibroListado(int id, String titulo, String autor, double precio) {
    setId(id);
   this.titulo = titulo;
    this.autor = autor;
    this.precio = precio;
  }
  public String getTitulo() {
    return titulo;
  }
  public String getAutor() {
    return autor;
  }
  public double getPrecio() {
    return precio;
  }
  public int getId() {
    return id;
  }
  public void setId(int id) {
    this.id = id;
  }
}