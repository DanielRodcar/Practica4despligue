package es.studium.Libros;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.studium.LibreriaMVC.Autor;
import es.studium.LibreriaMVC.Editorial;
import es.studium.LibreriaMVC.LibreriaMVC;

/**
 * Servlet implementation class ModificarLibroServlet
 */
@WebServlet("/ModificarLibroServlet")
public class ModificarLibroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static Libro libro;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModificarLibroServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LibreriaMVC.cargarDatosLibros();
		request.setAttribute("books", LibreriaMVC.getLibros());			
		RequestDispatcher dispatcher= request.getRequestDispatcher("/libros.jsp");			
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Obtenemos el Id del libro a modificar y consultamos sus datos -> Datos Libro
		int idLibroModificar = Integer.valueOf(request.getParameter("id_libro"));
		String titulo = request.getParameter("titulo");
		Double precio=Double.valueOf(request.getParameter("precio"));
		int cantidad=Integer.valueOf(request.getParameter("cantidad"));
		int autor =Integer.valueOf(request.getParameter("idautor"));
		int editorial=Integer.valueOf(request.getParameter("ideditorial"));
		  Libro libropasar = new Libro( idLibroModificar,  titulo,  autor, editorial,  precio, cantidad);
		  String cadenaerror=LibreriaMVC.modificarlibro(libropasar);
		  if(cadenaerror.isEmpty()) {
			  request.setAttribute("Mensaje", "No ha habido errores");
		  }else {
			  request.setAttribute("Mensaje", "No pudo completarse el cambio de forma correcta: "+cadenaerror);
		  }
		  
		
		LibreriaMVC.cargarDatosAutor();
		ArrayList<Autor> autores = (ArrayList<Autor> ) LibreriaMVC.getAutores();
		
		
		// Obtenemos los datos de los editorales -> DatosEditoriales
		LibreriaMVC.cargarDatosEditorial();
		ArrayList<Editorial> editoriales = (ArrayList<Editorial>) LibreriaMVC.getEditoriales();
		request.setAttribute("book", LibreriaMVC.getLibro( idLibroModificar));
		
		request.setAttribute("authors", autores);
		request.setAttribute("editorials", editoriales);
		
		
		RequestDispatcher dispatcher= request.getRequestDispatcher("/ModificarLibro.jsp");
		
		dispatcher.forward(request, response);
		
		
		
	}

}
