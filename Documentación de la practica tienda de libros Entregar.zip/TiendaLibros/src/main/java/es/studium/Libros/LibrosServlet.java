package es.studium.Libros;

import java.io.IOException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;
import javax.sql.DataSource;

import es.studium.LibreriaMVC.Autor;
import es.studium.LibreriaMVC.Editorial;
import es.studium.LibreriaMVC.LibreriaMVC;
import es.studium.LibreriaMVC.LibreriaMVC.*;

/**
 * Servlet implementation class LibrosServlet
 */
@WebServlet("/LibrosServlet")
public class LibrosServlet extends HttpServlet {	
	private static final long serialVersionUID = 1L;
	private DataSource pool;
	
	 public void init(ServletConfig config) throws ServletException
	    {
		    try
		    {
		    	// 	Crea un contexto para poder luego buscar el recurso DataSource
		    	InitialContext ctx = new InitialContext();
		    	// 	Busca el recurso DataSource en el contexto
		    	pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
		    	
		    	if(pool == null)
		    	{
		    		throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
		    	}
		    	
		    	LibreriaMVC.cargarDatosLibros();
		    }
	    	catch(NamingException ex){}
	    }
	 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LibrosServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//ServletContext servletContext = getServletContext();
		
		String id_libro = request.getParameter("id_libro");
		
		
		// Obtenemos el listado de los autores -> DatosAutores
		LibreriaMVC.cargarDatosAutor();
		ArrayList<Autor> autores = (ArrayList<Autor> ) LibreriaMVC.getAutores();
		
		
		// Obtenemos los datos de los editorales -> DatosEditoriales
		LibreriaMVC.cargarDatosEditorial();
		ArrayList<Editorial> editoriales = (ArrayList<Editorial>) LibreriaMVC.getEditoriales();
		request.setAttribute("book", LibreriaMVC.getLibro( Integer.parseInt(id_libro)));
		
		request.setAttribute("authors", autores);
		request.setAttribute("editorials", editoriales);
		
		
		RequestDispatcher dispatcher= request.getRequestDispatcher("/ModificarLibro.jsp");
		
		dispatcher.forward(request, response);
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if( request.getParameter("id_libro")==null) {
		LibreriaMVC.cargarDatosAutor();
		ArrayList<Autor> autores = (ArrayList<Autor> ) LibreriaMVC.getAutores();
		LibreriaMVC.cargarDatosEditorial();
		ArrayList<Editorial> editoriales = (ArrayList<Editorial>) LibreriaMVC.getEditoriales();
		request.setAttribute("authors", autores);
		request.setAttribute("editorials", editoriales);
	
	RequestDispatcher dispatcher= request.getRequestDispatcher("/AltaLibro.jsp");
	
	dispatcher.forward(request, response);
		}else {
			String id_libro=request.getParameter("id_libro");
			String posible_error=LibreriaMVC.borrarlibroconid( Integer.parseInt(id_libro));
			LibreriaMVC.cargarDatosLibros();
			request.setAttribute("books", LibreriaMVC.getLibros());
			request.setAttribute("mensaje", posible_error);
			RequestDispatcher dispatcherlibro= request.getRequestDispatcher("/libros.jsp");			
			dispatcherlibro.forward(request, response);
		}
	
	}
}
