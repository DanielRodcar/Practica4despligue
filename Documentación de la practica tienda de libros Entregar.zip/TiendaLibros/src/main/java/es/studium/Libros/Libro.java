package es.studium.Libros;

public class Libro implements Cloneable {
  private int id;
  private String titulo;
  private int idAutor;
  private int idEditorial;
  private double precio;
  private int cantidad;
  
	  public Libro() {
	    setId(0);
	    titulo = "";
	    idAutor = 0;
	    idEditorial = 0;
	    precio = 0.0;
	    cantidad=0;
	  }
	  public Libro(String titulo, int idAutor, int idEditorial, double precio, int cantidad) {
		super();
		this.titulo = titulo;
		this.idAutor = idAutor;
		this.idEditorial = idEditorial;
		this.precio = precio;
		this.cantidad = cantidad;
	}
	public Libro(int id, String titulo, int idautor, int ideditorial, double precio,int cantidad) {
	    setId(id);
	    this.titulo = titulo;
	    this.idAutor = idautor;
	    this.idEditorial = ideditorial;
	    this.precio = precio;
	    this.cantidad=cantidad;
	  }
	  public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public int getId() {
	    return id;
	  }
	  public String getTitulo() {
		return titulo;
	}
	public void setId(int id) {
	    this.id = id;
	  }
	public int getIdAutor() {
		return idAutor;
	}
	public void setIdAutor(int idAutor) {
		this.idAutor = idAutor;
	}
	public int getIdEditorial() {
		return idEditorial;
	}
	public double getPrecio() {
		return precio;
	}
	public void setIdEditorial(int idEditorial) {
		this.idEditorial = idEditorial;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
}