package es.studium.Pedidos;

import java.util.Date;

public class PedidoListar implements Cloneable {
	int id;
	String usuario;
	Date fecha_Pedido;
	Date Fecha_procesado;
	Double Importe;
	public PedidoListar() {
		id=0;
		usuario="";
		fecha_Pedido=null;
		Importe=0.0;
		Fecha_procesado=null;
	}
	public PedidoListar(int id, String usuario, Date fecha_Pedido, Double importe,Date procesado) {
		super();
		this.id = id;
		this.usuario = usuario;
		this.fecha_Pedido = fecha_Pedido;
		this.Importe = importe;
		this.Fecha_procesado=procesado;
	}
	public Date getFecha_procesado() {
		return Fecha_procesado;
	}
	public void setFecha_procesado(Date fecha_procesado) {
		Fecha_procesado = fecha_procesado;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public Date getFecha_Pedido() {
		return fecha_Pedido;
	}
	public void setFecha_Pedido(Date fecha_Pedido) {
		this.fecha_Pedido = fecha_Pedido;
	}
	public Double getImporte() {
		return Importe;
	}
	public void setImporte(Double importe) {
		Importe = importe;
	}

	
	
	
	
	
}