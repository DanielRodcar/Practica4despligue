package es.studium.Pedidos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.studium.LibreriaMVC.LibreriaMVC;

@WebServlet("/ShoppingServlet")
public class ShoppingServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
     * @see HttpServlet#HttpServlet()
     */

  public void init(ServletConfig conf) throws ServletException {
    super.init(conf);
    LibreriaMVC.cargarDatosLibros();
  }

  /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,
  IOException {
    LibreriaMVC.cargarDatosPedidos();
	request.setAttribute("pedidos", LibreriaMVC.getPedidos());			
	RequestDispatcher dispatcherpedido= request.getRequestDispatcher("/Pedidos.jsp");			
	dispatcherpedido.forward(request, response);
  }

  /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
  IOException {
    // TODO Auto-generated method stub
    request.setCharacterEncoding("UTF-8");
    // Recupera la sesión actual o crea una nueva si no existe
    HttpSession session = request.getSession(true);
    // Recupera el carrito de la sesión actual
    @SuppressWarnings("unchecked")
    ArrayList < ElementoPedido > elCarrito = (ArrayList < ElementoPedido > )
    session.getAttribute("carrito");
    // Determina a qué página jsp se redirigirá
    String nextPage = "";
    String todo = request.getParameter("todo");
    if (todo == null) {
    
      nextPage = "/AltaPedido.jsp";
    }
    else if (todo.equals("add")) {
    int IDlibroreal=LibreriaMVC.getidlibro(Integer.parseInt( request.getParameter("idLibro")));
      // Creamos un elementoPedido y lo añadimos al carrito
      ElementoPedido nuevoElementoPedido = new ElementoPedido(IDlibroreal,Integer.parseInt(request.getParameter("cantidad")));
      if (elCarrito == null) {
        // El carrito está vacío
        elCarrito = new ArrayList < >();
        elCarrito.add(nuevoElementoPedido);
        // Enlazar el carrito con la sesión
        session.setAttribute("carrito", elCarrito);
      }
      else {
        // Comprueba si el libro está ya en el carrito
        // Si lo está, actualizamos la cantidad
        // Si no está, lo añadimos
        boolean encontrado = false;
        Iterator < ElementoPedido > iter = elCarrito.iterator();
        while (!encontrado && iter.hasNext()) {
          ElementoPedido unElementoPedido = (ElementoPedido) iter.next();
          if (unElementoPedido.getIdLibro() == nuevoElementoPedido.getIdLibro()) {
            unElementoPedido.setCantidad(unElementoPedido.getCantidad() + nuevoElementoPedido.getCantidad());
            encontrado = true;
          }
        }
        if (!encontrado) {
          // Lo añade al carrito
          elCarrito.add(nuevoElementoPedido);
        }
      }
      // Volvemos a order.jps para seguir con la compra
      nextPage = "/AltaPedido.jsp";
    }
    else if (todo.equals("remove")) {

      // Borra el elemento indiceElemento del carrito
      int indiceCarrito = Integer.parseInt(request.getParameter("indiceElemento"));
      elCarrito.remove(indiceCarrito);
      // Vuelve a order.jsp para seguir con la compra
      nextPage = "/AltaPedido.jsp";
    }
    else if (todo.equals("checkout")) {
      
      // Calcula el precio total de todos los elementos del carrito
      double precioTotal = 0;
      int cantidadTotalOrdenada = 0;
      for (ElementoPedido item: elCarrito) {
        double precio = item.getPrecio();
        int cantidadOrdenada = item.getCantidad();
        precioTotal += precio * cantidadOrdenada;
        cantidadTotalOrdenada += cantidadOrdenada;
      }
      int idusuario=(int) session.getAttribute("idusuario");
      LibreriaMVC.AltaPedido(elCarrito,idusuario);
      // Da formato al precio con dos decimales
      StringBuilder sb = new StringBuilder();
      Formatter formatter = new Formatter(sb);
      formatter.format("%.2f", precioTotal);
      formatter.close();
      // Coloca el precioTotal y la cantidadtotal en el request
      request.setAttribute("precioTotal", sb.toString());
      request.setAttribute("cantidadTotal", cantidadTotalOrdenada + "");
      // Redirige a checkout.jsp
      nextPage = "/checkout.jsp";
    }
    ServletContext servletContext = getServletContext();
    RequestDispatcher requestDispatcher = servletContext.getRequestDispatcher(nextPage);
    requestDispatcher.forward(request, response);
  }


}
