package es.studium.Pedidos;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.studium.LibreriaMVC.LibreriaMVC;

/**
 * Servlet implementation class PedidosServlet
 */
@WebServlet("/PedidosServlet")
public class PedidosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PedidosServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id_pedido = request.getParameter("id_pedido");
	
		LibreriaMVC.cargarDetallePedido( Integer.parseInt(id_pedido));
		request.setAttribute("idpedido", id_pedido);
		request.setAttribute("detallepedido", LibreriaMVC.getDetallePedido());
		String fechaprocesado = request.getParameter("fecha_procesado") .equals("null")  ? "" : request.getParameter("fecha_procesado");

		request.setAttribute("fecha_procesado",fechaprocesado);
		request.setAttribute("detallepedido", LibreriaMVC.getDetallePedido());
		RequestDispatcher dispatcher= request.getRequestDispatcher("/DetallePedido.jsp");
		
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LibreriaMVC.cargarDatosLibros();
		
		
		RequestDispatcher dispatcher= request.getRequestDispatcher("/AltaPedido.jsp");
		
		dispatcher.forward(request, response);
	}

}
