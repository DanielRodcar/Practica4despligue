package es.studium.LibreriaMVC;

import java.util.Date;

public class DetallePedido implements Cloneable {
	private String libro;
	private double precioLibro;
	private int cantidad;
	private Date fecha;
	private double importeTotal;
	public DetallePedido(String libro, double precioLibro, int cantidad, Date fecha, double importeTotal) {
		super();
		this.libro = libro;
		this.precioLibro = precioLibro;
		this.cantidad = cantidad;
		this.fecha = fecha;
		this.importeTotal = importeTotal;
	}
	public String getLibro() {
		return libro;
	}
	public void setLibro(String libro) {
		this.libro = libro;
	}
	public double getPrecioLibro() {
		return precioLibro;
	}
	public void setPrecioLibro(double precioLibro) {
		this.precioLibro = precioLibro;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public double getImporteTotal() {
		return importeTotal;
	}
	public void setImporteTotal(double importeTotal) {
		this.importeTotal = importeTotal;
	}
	
}