package es.studium.LibreriaMVC;

public class Autor implements Cloneable {
  private int id;
  private String nombre;
  
  
  public Autor() {
    setId(0);
    nombre = "";    
  }
  public Autor(int id, String nombre) {
    setId(id);
    this.nombre = nombre;
  }
  
  public String getNombre() {
    return nombre;
  }
  
  public int getId() {
    return id;
  }
  private void setId(int id) {
    this.id = id;
  }
}