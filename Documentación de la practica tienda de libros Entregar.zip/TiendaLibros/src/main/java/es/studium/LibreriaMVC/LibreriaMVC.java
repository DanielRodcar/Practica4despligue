package es.studium.LibreriaMVC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.sql.DataSource;

import es.studium.Libros.Libro;
import es.studium.Libros.LibroListado;
import es.studium.Pedidos.ElementoPedido;
import es.studium.Pedidos.PedidoListar;

public class LibreriaMVC {
  static ArrayList <LibroListado> libros = new ArrayList<LibroListado>();
  static ArrayList <PedidoListar> pedidos = new ArrayList<PedidoListar>();
  static ArrayList<Autor> autores = new ArrayList<Autor>();
  static ArrayList<Editorial> editoriales= new ArrayList<Editorial>();
  static ArrayList<DetallePedido> detalles= new ArrayList<DetallePedido>();
  
  public static void cargarDatosLibros() {
    // Creamos objetos para la conexión
    Connection conn = null;
    Statement stmt = null;
    DataSource pool;
   libros=new ArrayList <LibroListado>();
    try {
		 InitialContext ctx = new InitialContext();
		 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
			
		if(pool == null)		{
			throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
		}
		conn = pool.getConnection();
      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
      stmt = conn.createStatement();
      //Paso 4: Ejecutar las sentencias
      String sqlStr = "select  id_Libro, a.nombre as autorLibro, l.Titulo as tituloLibro, l.Precio as precioLibro from libro l join autores a on a.id_autor = l.id_autorfk";
      ResultSet rs = stmt.executeQuery(sqlStr);
      LibroListado libro;
      while (rs.next()) {
        libro = new LibroListado(rs.getInt("id_Libro"), rs.getString("autorLibro"), rs.getString("tituloLibro"), rs.getDouble("precioLibro"));
        libros.add(libro);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
    finally {
      try {
        //Cerramos el resto de recursos
        if (stmt != null) {
          stmt.close();
        }
        if (conn != null) {
          conn.close();
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
  }
  
  public static void cargarDatosPedidos() {
	    // Creamos objetos para la conexión
	    Connection conn = null;
	    Statement stmt = null;
	    DataSource pool;
	
	   pedidos=new ArrayList <PedidoListar>();
	    try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();
	      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
	      stmt = conn.createStatement();
	      //Paso 4: Ejecutar las sentencias
	      String sqlStr = "SELECT  p.Id_pedido, p.FechaPedido, p.ImporteTotal,nombre,p.FechaProcesado FROM pedido p,usuarios  where Id_usuario=Id_usuariofk \r\n"
	      		+ "order by FechaProcesado IS NULL DESC,FechaPedido ";
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      PedidoListar pedido;
	      while (rs.next()) {
	    		
	    	  pedido = new PedidoListar(rs.getInt("Id_pedido"),rs.getString("nombre"), rs.getDate("FechaPedido"), rs.getDouble("ImporteTotal"),rs.getDate("FechaProcesado"));
	    	  pedidos.add(pedido);
	      }
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	    }
	  }
  public static PedidoListar getPedido(int idpedido) {
	    // Creamos objetos para la conexión
	    Connection conn = null;
	    Statement stmt = null;
	    DataSource pool;
	    PedidoListar pedido=new PedidoListar();
	   
	    try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();
	      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
	      stmt = conn.createStatement();
	      //Paso 4: Ejecutar las sentencias
	      String sqlStr = "SELECT  p.Id_pedido, p.FechaPedido, p.ImporteTotal,u.nombre,p.FechaProcesado\r\n"
	      		+ "	      		FROM pedido p,usuarios u\r\n"
	      		+ "	      		 where Id_usuario=Id_usuariofk and Id_pedido="+idpedido;
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      
	      while (rs.next()) {
	    		
	    	  pedido = new PedidoListar(rs.getInt("Id_pedido"),rs.getString("nombre"), rs.getDate("FechaPedido"), rs.getDouble("ImporteTotal"),rs.getDate("FechaProcesado"));
	    	
	      }
	     
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	    }
		return pedido;
	  }
  public static void cambiarestadoFechapedido(int idpedido) {
	  Connection conn = null;
	  PreparedStatement stmt = null;
	  DataSource pool;
    
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	   
	      stmt = conn.prepareStatement("update  pedido set FechaProcesado=now() where Id_pedido=?");
	     stmt.setDouble(1,idpedido);
	      
	      stmt.executeUpdate();
	      
	    }
	    catch(Exception ex) {
	      //ex.printStackTrace();
	    	ex.getMessage();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
  }
  
  
  
  public static void cargarDatosAutor() {
	    // Creamos objetos para la conexión
	    Connection conn = null;
	    Statement stmt = null;
	    DataSource pool;
	    autores=new ArrayList <Autor>();
	   
	    try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();
	      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
	      stmt = conn.createStatement();
	      //Paso 4: Ejecutar las sentencias
	      String sqlStr = "select Id_autor,Nombre from autores order by Nombre";
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      Autor autor;
	      while (rs.next()) {
	        autor = new Autor(rs.getInt("Id_autor"), rs.getString("Nombre"));
	        autores.add(autor);
	      }
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	    }
	  }

  public static void cargarDatosEditorial() {
	    // Creamos objetos para la conexión
	    Connection conn = null;
	    Statement stmt = null;
	    DataSource pool;
	    editoriales= new ArrayList<Editorial>();
	    try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();
	      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
	      stmt = conn.createStatement();
	      //Paso 4: Ejecutar las sentencias
	      editoriales.clear();
	      String sqlStr = "  select Id_editorial, Nombre from editoriales order by Nombre";
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      Editorial editorial;
	      while (rs.next()) {
	        editorial = new Editorial(rs.getInt("id_editorial"), rs.getString("nombre"));
	        editoriales.add(editorial);
	      }
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	    }
	  }
  public static void cargarDetallePedido(int idpedido) {
	    // Creamos objetos para la conexión
	    Connection conn = null;
	    Statement stmt = null;
	    DataSource pool;
	    detalles= new ArrayList<DetallePedido>();
	    try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();
	      //Paso 3: Crear las sentencias SQL utilizando objetos de la clase Statement
	      stmt = conn.createStatement();
	      //Paso 4: Ejecutar las sentencias
	      detalles.clear();
	      String sqlStr = "select Titulo,Precio,Cantidad,FechaPedido,cantidad*precio as importetotal\r\n"
	      		+ "	      		from libro,pedido,detallepedido\r\n"
	      		+ "	      		where Id_pedido=Id_PedidoFK and Id_libroFK=Id_libro and Id_PedidoFK="+idpedido;
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      Editorial editorial;
	      while (rs.next()) {
	    	 
	    	  Date fechaPedido = rs.getDate("FechaPedido");
	    	  DetallePedido detalle = new DetallePedido(rs.getString("Titulo"), rs.getDouble("Precio"), rs.getInt("cantidad"), fechaPedido, rs.getDouble("importetotal"));
	    	  detalles.add(detalle);

	      }
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	    }
	  }
  public static int getidlibro(int indice) { 
	  return libros.get(indice).getId();
  }
  public static String getAutor(int indice) { 
	  return libros.get(indice).getAutor();
	  }
  public static double getPrecio(int indice) {
	  return libros.get(indice).getPrecio();
	  }
  public static String getTitulo(int indice) { 
	  return libros.get(indice).getTitulo(); 
	  }
  
  public static int tamano()
  {
  return libros.size();
  }

  public static ArrayList <PedidoListar> getPedidos(){
	  return (ArrayList<PedidoListar>) pedidos.clone();
  }
  public static ArrayList <DetallePedido> getDetallePedido(){
	  return (ArrayList<DetallePedido>) detalles.clone();
  }
  public static ArrayList <LibroListado> getLibros(){
	  return (ArrayList<LibroListado>) libros.clone();
  }
  public static ArrayList <Autor> getAutores(){
	  return (ArrayList<Autor>) autores.clone();
  }
  public static ArrayList <Editorial> getEditoriales(){
	  return (ArrayList<Editorial>) editoriales.clone();
  }
  public static Libro getLibro(int idLibro) {
	  Connection conn = null;
	  Statement stmt = null;
	  DataSource pool;
      Libro libro = new Libro();
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	      stmt = conn.createStatement();
	      String sqlStr = "select Id_Libro, l.Titulo, l.Precio, l.id_autorfk as idAutor,l.Cantidad_stock, l.id_editorialfk as idEditorial from libro l where Id_Libro = " + idLibro;
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      while (rs.next()) {
	  
	        libro = new Libro(rs.getInt("Id_Libro"), rs.getString("Titulo"), rs.getInt("idAutor"), rs.getInt("idEditorial"), rs.getDouble("Precio"),rs.getInt("Cantidad_stock"));	        
	      }
	      
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return libro;
  }
  public static Autor getAutorporid(int idautor) {
	  Connection conn = null;
	  Statement stmt = null;
	  DataSource pool;
	  Autor   autor=new Autor() ;
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	      stmt = conn.createStatement();
	      String sqlStr = "select Id_autor,Nombre from autores where Id_autor=" + idautor;
	      ResultSet rs = stmt.executeQuery(sqlStr);
	      while (rs.next()) {
	  
	     autor = new Autor(rs.getInt("Id_autor"), rs.getString("Nombre"));	        
	      }
	      
	    }
	    catch(Exception ex) {
	      ex.printStackTrace();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return autor;
  }
  public static String AltaLibro(Libro libroagregar) {
	  Connection conn = null;
	  PreparedStatement stmt = null;
	  DataSource pool;
    
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	   
	      stmt = conn.prepareStatement("insert into  libro(Titulo,Precio,Cantidad_stock,Id_autorfk,id_Editorialfk) values(?,?,?,?,?)");
	      stmt.setString(1,libroagregar.getTitulo());
	      stmt.setDouble(2,libroagregar.getPrecio());
	      stmt.setInt(3,libroagregar.getCantidad());
	      stmt.setInt(4,libroagregar.getIdAutor());
	      stmt.setInt(5,libroagregar.getIdEditorial());
	      stmt.execute();
	    }
	    catch(Exception ex) {
	      //ex.printStackTrace();
	      return ex.getMessage();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return "";
  }
  public static String borrarlibroconid(int idLibro) {
	  Connection conn = null;
	  PreparedStatement stmt = null;
	  DataSource pool;
    
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	   
	      stmt = conn.prepareStatement("delete from libro where Id_libro=?");
	      stmt.setInt(1,idLibro);
	     
	      stmt.execute();
	    }
	    catch(Exception ex) {
	      //ex.printStackTrace();
	      return ex.getMessage();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return"";
  }
  public static String AltaPedido(ArrayList<ElementoPedido> carrito, int idusuario) {
	  Connection conn = null;
	  PreparedStatement stmt = null;
	  DataSource pool;
    
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
			conn.setAutoCommit(false);
			Double importetotal = 0.0;

			for (ElementoPedido elementopedido : carrito) {
			    Double precio = elementopedido.getPrecio()*elementopedido.getCantidad();
			    if(null != precio) importetotal += precio;
			}
	      stmt = conn.prepareStatement("INSERT INTO Pedido ( FechaProcesado, FechaPedido, Id_usuariofk,ImporteTotal)\r\n"
	      		+ "VALUES ( null, now(), ?,?)");
	      stmt.setInt(1,idusuario);
	      stmt.setDouble(2,importetotal);
	      
	      stmt.execute();
	      var rs = stmt.executeQuery("select last_insert_id() as last_id from pedido");
	      rs.next();
	      int idPedido = rs.getInt("last_id");
	      for(int i=0;i<carrito.size();i++) {
	    	  stmt = conn.prepareStatement("INSERT INTO DetallePedido ( Cantidad, Importe, Id_PedidoFK, Id_libroFK)\r\n"
	    	  		+ "	 VALUES ( ?, ?, ?, ?) ");
	    	  stmt.setInt(1,carrito.get(i).getCantidad());
		      stmt.setDouble(2,carrito.get(i).getPrecio());
		      stmt.setInt(3,idPedido);
		      stmt.setInt(4,carrito.get(i).getIdLibro());
		      stmt.execute();
	    	        
	      }
	      
	      conn.commit();
	      
	    }
	    catch(Exception ex) {
	     if(conn!=null)
			try {
				conn.rollback();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	      return ex.getMessage();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return "";
  }
  public static String modificarlibro(Libro libromodificar) {
	  Connection conn = null;
	  PreparedStatement stmt = null;
	  DataSource pool;
    
	   
	  try {
			 InitialContext ctx = new InitialContext();
			 pool = (DataSource)ctx.lookup("java:comp/env/jdbc/mysql_tiendalibros");
				
			if(pool == null)		{
				throw new ServletException("DataSource desconocida 'mysql_tiendalibros'");
			}
			conn = pool.getConnection();	     
	   
	      stmt = conn.prepareStatement("update  libro set Titulo=?,Precio=?,Cantidad_stock=?,Id_autorfk=?,id_Editorialfk=? where Id_Libro=?");
	      stmt.setString(1,libromodificar.getTitulo());
	      stmt.setDouble(2,libromodificar.getPrecio());
	      stmt.setInt(3,libromodificar.getCantidad());
	      stmt.setInt(4,libromodificar.getIdAutor());
	      stmt.setInt(5,libromodificar.getIdEditorial());
	      stmt.setInt(6,libromodificar.getId());
	      stmt.executeUpdate();
	      
	    }
	    catch(Exception ex) {
	      //ex.printStackTrace();
	      return ex.getMessage();
	    }
	    finally {
	      try {
	        //Cerramos el resto de recursos
	        if (stmt != null) {
	          stmt.close();
	        }
	        if (conn != null) {
	          conn.close();
	        }
	        
	      }
	      catch(Exception ex) {
	        ex.printStackTrace();
	      }
	   }
	  return "";
  }
}