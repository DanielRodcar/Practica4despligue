package es.studium.Menu;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.studium.LibreriaMVC.LibreriaMVC;

/**
 * Servlet implementation class MenuServlet
 */
@WebServlet("/MenuServlet")
public class MenuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MenuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String opcion = request.getParameter("opcion");
		switch(opcion) {
		case "opcionLibros" :
				LibreriaMVC.cargarDatosLibros();
				request.setAttribute("books", LibreriaMVC.getLibros());			
				RequestDispatcher dispatcherlibro= request.getRequestDispatcher("/libros.jsp");			
				dispatcherlibro.forward(request, response);

				break;
		case "opcionautores" :
			
			LibreriaMVC.cargarDatosAutor();
			request.setAttribute("authors", LibreriaMVC.getAutores());		
			RequestDispatcher dispatcherautor= request.getRequestDispatcher("/autores.jsp");			
			dispatcherautor.forward(request, response);

			break;
	case "opcioneditorial" :
			
			LibreriaMVC.cargarDatosEditorial();
			request.setAttribute("editorials", LibreriaMVC.getEditoriales());		
			RequestDispatcher dispatchereditorial= request.getRequestDispatcher("/editoriales.jsp");			
			dispatchereditorial.forward(request, response);

			break;
	case "opcionespedido" :
		LibreriaMVC.cargarDatosPedidos();
		request.setAttribute("pedidos", LibreriaMVC.getPedidos());			
		RequestDispatcher dispatcherpedido= request.getRequestDispatcher("/Pedidos.jsp");			
		dispatcherpedido.forward(request, response);

		break;
		}
		

	}

	

}
